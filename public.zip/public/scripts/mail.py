from flask import Flask, request, render_template
import os
import sys
import smtplib
import json
from email.message import EmailMessage

app = Flask(__name__)
email = "chefcity.orders@gmail.com"
password = "group12353"

@app.route('/receiver', methods = ['POST'])
def worker():
	data = request.get_json()
	result = ''

	for item in data:
		result += str(item['make']) + '\n'

	return result

if __name__ == '__main__':
	app.run()

data = json.loads(worker())
reciever = data["email"]
subject = data["subject"]
body = data["body"]

message = EmailMessage()
message['Subject'] = subject
message['From'] = email
message['To'] = reciever
message.set_content(body)

with smtplib.SMTP_SSL('smtp.gmail.com',465) as smtp:
    smtp.login(email,password)

    smtp.send_message(message)