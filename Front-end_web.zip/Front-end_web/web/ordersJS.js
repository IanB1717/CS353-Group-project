function validateForm(){
	var supplier=document.getElementById('supplier').value;
	var item=document.getElementById('ingredient').value;
	var amount=document.getElementById('quantity').value;
	var weight=document.getElementById('measure').value;
	document.getElementById("confirm").innerHTML ="Thanks for your order. Email sent to "+supplier+". You want "+amount+" "+weight+" of "+item+".";
}